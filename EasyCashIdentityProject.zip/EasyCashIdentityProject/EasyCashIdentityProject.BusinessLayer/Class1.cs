﻿namespace EasyCashIdentityProject.BusinessLayer
{
    public class Class1
    {

    }
}
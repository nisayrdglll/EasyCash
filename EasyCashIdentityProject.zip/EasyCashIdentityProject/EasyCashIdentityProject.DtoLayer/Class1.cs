﻿namespace EasyCashIdentityProject.DtoLayer
{
    public class Class1
    {

    }
}